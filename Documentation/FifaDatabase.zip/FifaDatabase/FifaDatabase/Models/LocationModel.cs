﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FifaDatabase.Models
{
    class LocationModel
    {
        public int LOCATIONID { get; set; }
        public string COUNTRY { get; set; }
    }
}
