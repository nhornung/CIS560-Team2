﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FifaDatabase.Models
{
    public class TeamModel
    {
        public int TeamId { get; set; }
        public string Nation { get; set; }
    }
}
