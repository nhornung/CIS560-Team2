﻿CREATE OR ALTER PROCEDURE WorldCupSchema.RetrievePlayers
AS

SELECT *
FROM WorldCupSchema.Players P;
GO
